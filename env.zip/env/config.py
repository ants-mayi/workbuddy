# -*- coding: utf-8 -*-
"""
=============================================================================
主题配置 PROFILE —— 「本机开发环境」一条龙控制台
=============================================================================
基于脚手架生成，引擎在 engine/（本副本按本机主题做了克制定制，脚手架模板未改）。
所有主题信息集中在本文件；版本探测用绝对路径调用各工具，稳定复现。

数据来源（唯一事实源）：M:\\AI\\WorkBuddy\\电脑开发环境信息.md（2026-11-16 采集）
实测复核：2026-11-17。差异处以实测为准（如 git 2.55.0.windows.2）。
"""

PROFILE = {
    # ── 1. 身份 ───────────────────────────────────────────────────
    "name": "本机开发环境",
    "short": "env",
    "desc": "Windows 11 本机环境 · 版本 / 路径 / 服务 / 端口 一条龙速查",
    "docs_title": "本机开发环境速查",

    # ── 2. 路径 ───────────────────────────────────────────────────
    "paths": {
        "project": ".",
        "artifacts": "",           # 无模型产物
        "data": "",                # 无数据集
        "notes": "notes",          # 速查文档目录
        "web": "web",
        "cache": "",               # 缓存由 cache.items 单独列
    },

    # ── 3. 环境 / 版本探测 ────────────────────────────────────────
    # 每条 probe 用绝对路径调用外部命令，吞掉异常并 print 单行版本。
    # 引擎把全部 probe 拼进一个子进程按序执行（单进程 + 缓存，首次后秒回）。
    "env": {
        "python_exe": r"G:\workIns\conda\envs\pytorch\python.exe",
        "disk_drive": "C:\\",       # 体检关注系统盘剩余
        "mirror_host": "",          # 无镜像主机 → 跳过连通性检查
        "mirror_url": "",
        "versions": [
            {"label": "Python", "expect_major": "3",
             "probe": "import sys; print(sys.version.split()[0])"},

            {"label": "JDK", "expect_major": "17",
             "probe": '''import subprocess as _sp, re as _re
try:
    _r=_sp.run([r"D:\\wofkIns\\jdk-17.0.0.1\\bin\\java.exe","-version"],capture_output=True,text=True,timeout=25)
    _m=_re.search(r'"([0-9][^"]*)"',(_r.stdout or "")+(_r.stderr or ""))
    print(_m.group(1) if _m else "-")
except Exception:
    print("-")'''},

            {"label": "Maven", "expect_major": "3",
             "probe": '''import subprocess as _sp, re as _re
try:
    _r=_sp.run(["cmd","/c",r"D:\\wofkIns\\apache-maven-3.9.9\\bin\\mvn.cmd","-version"],capture_output=True,text=True,timeout=30)
    _m=_re.search(r"Apache Maven ([0-9][^ ]*)",(_r.stdout or "")+(_r.stderr or ""))
    print(_m.group(1) if _m else "-")
except Exception:
    print("-")'''},

            {"label": "Node.js", "expect_major": "22",
             "probe": '''import subprocess as _sp
try:
    _r=_sp.run([r"C:\\Users\\marco\\.workbuddy\\binaries\\node\\versions\\22.22.2-6\\node.exe","-v"],capture_output=True,text=True,timeout=20)
    print((_r.stdout or "").strip().lstrip("v") or "-")
except Exception:
    print("-")'''},

            {"label": "npm", "expect_major": "10",
             "probe": '''import subprocess as _sp
try:
    _r=_sp.run(["cmd","/c",r"C:\\Users\\marco\\.workbuddy\\binaries\\node\\versions\\22.22.2-6\\npm.cmd","-v"],capture_output=True,text=True,timeout=20)
    print((_r.stdout or "").strip().splitlines()[0] or "-")
except Exception:
    print("-")'''},

            {"label": "Git", "expect_major": "2",
             "probe": '''import subprocess as _sp, re as _re
try:
    _r=_sp.run([r"D:\\wofkIns\\Git\\cmd\\git.exe","--version"],capture_output=True,text=True,timeout=20)
    _m=_re.search(r"git version ([0-9][^ ]*)",(_r.stdout or "")+(_r.stderr or ""))
    print(_m.group(1) if _m else "-")
except Exception:
    print("-")'''},

            {"label": "Conda", "expect_major": "26",
             "probe": '''import subprocess as _sp, re as _re
try:
    _r=_sp.run([r"D:\\wofkIns\\anaconda3\\Scripts\\conda.exe","--version"],capture_output=True,text=True,timeout=25)
    _m=_re.search(r"conda\\s+([0-9][^\\s]*)",(_r.stdout or "")+(_r.stderr or ""))
    print(_m.group(1) if _m else "-")
except Exception:
    print("-")'''},

            {"label": "torch", "expect_major": "2",
             "probe": "import torch; print(torch.__version__)"},
            {"label": "transformers", "expect_major": "5",
             "probe": "import transformers; print(transformers.__version__)"},
            {"label": "Flask", "expect_major": "3",
             "probe": "import flask; print(flask.__version__)"},
        ],
        # GPU 属本机环境的一部分，保留探测
        "gpu": {
            "probe": "import torch; print('TRUE' if torch.cuda.is_available() else 'FALSE')",
            "name_probe": "import torch; print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else '-')",
        },
    },

    # ── 4. 服务：本主题无推理脚本服务 ─────────────────────────────
    "serve": {"enabled": False},
    "web_port": 8010,               # 避开 HF 控制台 8000

    # ── 5. 数据 / 产物 / 曲线：本主题均不适用（留空）──────────────
    "data": {"files": [], "sample_file": "", "sample_col": "",
             "label_source": "", "label_note": "本机开发环境主题无数据集；服务/端口见「服务与端口」面板。"},
    "artifacts": {
        "meanings": {}, "must_exist": [], "metrics_files": [],
        "history_file": "", "history_key": "", "curve_metrics": [], "x_key": "step",
    },

    # ── 6. 缓存占用（只读，全部 safe=False，不提供删除系统缓存）──
    "cache": {"items": [
        {"name": "Conda packages (G 盘)", "path": r"G:\workIns\conda\pkgs", "safe": False,
         "note": "G 盘 AI 环境的包缓存，约 2.6 GB；删除前确认环境不再需要"},
        {"name": "HF 缓存", "path": r"G:\study\AI\cache\huggingface", "safe": False,
         "note": "模型/数据集缓存，删除后需重新下载"},
        {"name": "npm 缓存", "path": r"C:\Users\marco\AppData\Local\npm-cache", "safe": False},
        {"name": "Maven 本地仓库", "path": r"C:\Users\marco\.m2\repository", "safe": False},
        {"name": "pip 缓存", "path": r"C:\Users\marco\AppData\Local\pip\Cache", "safe": False},
    ]},

    # ── 7. recap 核心速记 ─────────────────────────────────────────
    "recap": {
        "core": "唯一事实源：M:\\AI\\WorkBuddy\\电脑开发环境信息.md（23 节）\n"
                "AI 解释器只有 G:\\workIns\\conda\\envs\\pytorch\\python.exe（torch 2.11+cu126 / transformers 5.8），不在 PATH\n"
                "PATH 里的 python 有 3 套（3.13.14 / 3.14 / 3.13.9）但都没有 AI 库；装包一律 python -m pip\n"
                "两套 Conda：D 盘 wofkIns（PATH 中，仅 base）/ G 盘 workIns（AI 环境所在）",
        "rules": [
            "AI 任务固定用 G 盘 pytorch 环境解释器，PATH 里的 python 没有 torch",
            "远程/串流端口常驻：Sunshine 47984/47989/47990/48010、Tailscale UDP 41641；调试端口先排查它们",
            "MySQL 三套、服务均未启动且两套同配 3306；用前先定哪套并错开端口（推荐 8.0 用 3307）",
            ".NET 只有运行时无 SDK；dotnet --version 报错属正常；Ollama/Docker/Gradle 未装",
            "C 盘余 ~38 GB、D 盘余 ~12 GB 偏紧，新软件/模型放 E/F/M 盘",
            "验证软件是否就绪用三层法：①有没有 → ②环境齐不齐 → ③跑个最小任务",
        ],
        "commands_note": "忘记先看 env status / env recap；检验记忆用 env quiz；环境异常用 env doctor；服务端口看 Web「服务与端口」。",
    },

    "extra_checks": [],             # 引擎的 extra_checks 仅支持 json_key，本主题不用
    "question_module": "question_bank.py",

    # ── 8. 主题定制字段（引擎副本读取；脚手架模板不认识，不影响）──
    "ui": {
        # Web 面板显示顺序（面向"查询 + 操作"，移除记忆抽测 quiz）
        # pathtruth=PATH真相 / envvars=环境变量 / ports_live=实时端口 / processes=关键进程 / cmdlib=命令库
        "sections": ["status", "info", "pathtruth", "envvars", "software", "servicesvc",
                     "ports_live", "processes", "test", "doctor", "cmdlib", "cache", "docs"],
    },
    "facts": {
        # 关键路径（status 面板展示存在性）
        "paths": [
            {"name": "环境手册（事实源）", "path": r"M:\AI\WorkBuddy\电脑开发环境信息.md"},
            {"name": "AI 环境解释器", "path": r"G:\workIns\conda\envs\pytorch\python.exe"},
            {"name": "HF 缓存", "path": r"G:\study\AI\cache\huggingface"},
            {"name": "JDK", "path": r"D:\wofkIns\jdk-17.0.0.1"},
            {"name": "Maven", "path": r"D:\wofkIns\apache-maven-3.9.9"},
            {"name": "Git", "path": r"D:\wofkIns\Git\cmd\git.exe"},
            {"name": "Tailscale", "path": r"F:\Game\tailscale"},
            {"name": "VSCode", "path": r"D:\softIns\Microsoft VS Code"},
            {"name": "IDEA Ultimate", "path": r"D:\wofkIns\ideaIU-2025.1.win"},
            {"name": "DBeaver", "path": r"D:\wofkIns\dbeaver-ce-25.1.3-win32.win32.x86_64"},
            {"name": "Postman", "path": r"C:\Users\marco\AppData\Local\Postman"},
        ],
        # Windows 服务：查询用 Get-Service，启动命令供复制
        "services": [
            {"name": "Sunshine 串流", "svc": "SunshineService", "expect": "Running",
             "start": "net start SunshineService  (管理员)", "note": "TCP 47984/47989/47990/48010"},
            {"name": "Tailscale 组网", "svc": "Tailscale", "expect": "Running",
             "start": "net start Tailscale  (管理员)", "note": "UDP 41641；本机 IP 100.75.245.81"},
            {"name": "UU远程 GameViewer", "svc": "GameViewerService", "expect": "Running",
             "start": "net start GameViewerService  (管理员)", "note": "远程游戏服务"},
            {"name": "MySQL 5.7", "svc": "MySQL", "expect": "Stopped",
             "start": "net start MySQL  (管理员)", "note": "端口 3306；手动启动类型"},
            {"name": "MySQL 8.0", "svc": "mysql80", "expect": "Stopped",
             "start": "net start mysql80  (管理员)", "note": "端口 3307，推荐用这套"},
        ],
        # 常驻端口快照（来自环境手册 + 实测）
        "ports": [
            {"port": "47984 / 47989 / 47990 / 48010", "proto": "TCP", "use": "Sunshine 串流", "state": "监听中"},
            {"port": "41641", "proto": "UDP", "use": "Tailscale 组网", "state": "监听中"},
            {"port": "3306 / 3307", "proto": "TCP", "use": "MySQL（服务未启动）", "state": "未监听"},
            {"port": "11434", "proto": "TCP", "use": "Ollama（未安装）", "state": "未监听"},
            {"port": "8000 / 8010", "proto": "TCP", "use": "控制台 Web（HF / 本机环境）", "state": "按需"},
        ],
        # 磁盘快照（环境手册 2026-11-16 采集）
        "disks": [
            {"drive": "C:", "free_gb": 37.9, "note": "系统盘，偏紧"},
            {"drive": "D:", "free_gb": 12.4, "note": "很紧张"},
            {"drive": "E:", "free_gb": 391.9, "note": "充足"},
            {"drive": "F:", "free_gb": 318.2, "note": "充足"},
            {"drive": "G:", "free_gb": 82.4, "note": "AI 环境所在"},
            {"drive": "M:", "free_gb": 201.5, "note": "工作区所在"},
        ],

        # ── 基础信息：配置文件路径（2026-11-17 实测存在性）────────
        "config_files": [
            {"name": "环境手册（唯一事实源）", "path": r"M:\AI\WorkBuddy\电脑开发环境信息.md",
             "note": "23 节，软件升级/路径变更后先改这里"},
            {"name": "本控制台配置", "path": r"M:\AI\WorkBuddy\env\config.py",
             "note": "改版本探测/路径/面板都在这里"},
            {"name": "控制台题库（当前未启用）", "path": r"M:\AI\WorkBuddy\env\question_bank.py",
             "note": "已移除记忆抽测，文件保留备用"},
            {"name": "Git 全局配置", "path": r"C:\Users\marco\.gitconfig", "note": "user.name/email 等"},
            {"name": "Maven 仓库", "path": r"C:\Users\marco\.m2\repository", "note": "本地依赖；无 settings.xml（用默认中央仓库）"},
            {"name": "WorkBuddy MCP 配置", "path": r"C:\Users\marco\.workbuddy\mcp.json", "note": "自定义 MCP 服务"},
            {"name": "WorkBuddy 设置", "path": r"C:\Users\marco\.workbuddy\settings.json", "note": "全局设置"},
            {"name": "VSCode 用户设置", "path": r"C:\Users\marco\AppData\Roaming\Code\User\settings.json", "note": ""},
            {"name": "hosts 文件", "path": r"C:\Windows\System32\drivers\etc\hosts", "note": "需管理员修改"},
        ],
        # 常见于"配置文件"但本机不存在（如 ~/.npmrc、~/.m2/settings.xml、~/.ssh/config）——
        # 未列入上方，避免误报；需要时手动创建即可。

        # ── 基础信息：产物 / 工作目录路径 ──────────────────────────
        "products": [
            {"name": "AI 环境解释器", "path": r"G:\workIns\conda\envs\pytorch\python.exe",
             "note": "torch 2.11+cu126 / transformers 5.8，唯一带 AI 库的 Python"},
            {"name": "Python site-packages", "path": r"G:\workIns\conda\envs\pytorch\Lib\site-packages",
             "note": "AI 环境的第三方包装在这里"},
            {"name": "Conda envs（G 盘）", "path": r"G:\workIns\conda\envs", "note": "AI 环境所在"},
            {"name": "Conda envs（D 盘）", "path": r"D:\wofkIns\anaconda3\envs", "note": "仅 base，PATH 中的 Conda"},
            {"name": "HF 缓存（模型/数据集）", "path": r"G:\study\AI\cache\huggingface", "note": "HF_HOME，删除后需重下"},
            {"name": "Maven 本地仓库", "path": r"C:\Users\marco\.m2\repository", "note": "Java 依赖产物"},
            {"name": "pip 缓存", "path": r"C:\Users\marco\AppData\Local\pip\Cache", "note": "下载过的 wheel"},
            {"name": "npm 缓存", "path": r"C:\Users\marco\AppData\Local\npm-cache", "note": "Node 包缓存"},
            {"name": "控制台速查文档", "path": r"M:\AI\WorkBuddy\env\notes", "note": "6 份复习/查询文档"},
        ],

        # ── 软件状态：开发工具 + 运行时（版本实时探测，路径/操作来自此表）──
        # probe_label 对应 env.versions 的 label；引擎据此合并实时版本
        "software": [
            {"name": "JDK 17", "probe_label": "JDK", "path": r"D:\wofkIns\jdk-17.0.0.1",
             "category": "开发", "start": "", "note": "java -version；版本输出到 stderr"},
            {"name": "Maven 3.9", "probe_label": "Maven", "path": r"D:\wofkIns\apache-maven-3.9.9",
             "category": "开发", "start": "mvn -v", "note": "需 cmd /c 调用 .cmd"},
            {"name": "Node.js 22", "probe_label": "Node.js", "path": r"C:\Users\marco\.workbuddy\binaries\node\versions\22.22.2-6",
             "category": "开发", "start": "node -v", "note": "WorkBuddy 内置 node"},
            {"name": "npm 10", "probe_label": "npm", "path": r"C:\Users\marco\.workbuddy\binaries\node\versions\22.22.2-6\npm.cmd",
             "category": "开发", "start": "npm -v", "note": "需 cmd /c 调用 .cmd"},
            {"name": "Git", "probe_label": "Git", "path": r"D:\wofkIns\Git\cmd\git.exe",
             "category": "开发", "start": "git --version", "note": "实测 2.55.0.windows.2"},
            {"name": "Conda (D 盘)", "probe_label": "Conda", "path": r"D:\wofkIns\anaconda3\Scripts\conda.exe",
             "category": "环境", "start": "conda --version", "note": "PATH 中的 Conda，仅 base"},
            {"name": "Python (AI 环境)", "probe_label": "Python", "path": r"G:\workIns\conda\envs\pytorch\python.exe",
             "category": "环境", "start": "python -V", "note": "AI 任务固定用它，不在 PATH"},
            {"name": "PyTorch", "probe_label": "torch", "path": r"G:\workIns\conda\envs\pytorch\Lib\site-packages\torch",
             "category": "AI", "start": "python -c \"import torch;print(torch.__version__)\"", "note": "GPU 版 cu126"},
            {"name": "Transformers", "probe_label": "transformers", "path": "",
             "category": "AI", "start": "python -c \"import transformers;print(transformers.__version__)\"", "note": "v5.8.0"},
            {"name": "Flask", "probe_label": "Flask", "path": "",
             "category": "AI", "start": "python -c \"import flask;print(flask.__version__)\"", "note": "Web 控制台依赖"},
            {"name": "DBeaver 25.1", "probe_label": "", "path": r"D:\wofkIns\dbeaver-ce-25.1.3-win32.win32.x86_64",
             "category": "工具", "start": "dbeaver.exe", "note": "数据库客户端 CE 版"},
            {"name": "Postman 12", "probe_label": "", "path": r"C:\Users\marco\AppData\Local\Postman",
             "category": "工具", "start": "Postman.exe", "note": "接口调试"},
            {"name": "VSCode", "probe_label": "", "path": r"D:\softIns\Microsoft VS Code",
             "category": "工具", "start": "code", "note": "代码编辑器"},
            {"name": "IDEA Ultimate", "probe_label": "", "path": r"D:\wofkIns\ideaIU-2025.1.win",
             "category": "工具", "start": "idea64.exe", "note": "Java IDE"},
            {"name": "Docker", "probe_label": "", "path": r"C:\Program Files\Docker\Docker",
             "category": "未安装", "start": "", "note": "尚未安装，需要时再装"},
            {"name": "Ollama", "probe_label": "", "path": r"C:\Users\marco\AppData\Local\Programs\Ollama",
             "category": "未安装", "start": "", "note": "尚未安装；端口 11434"},
        ],

        # ── PATH 真相：命令实际解析（where 动态探测；expect 为期望路径片段）──
        # 判定：0 个=未找到；1 个=正常；多个=预警（第一个才是实际生效的）
        # expect 不在结果里=预警并给出说明（如 python 的 AI 解释器故意不在 PATH）
        "path_commands": [
            {"cmd": "python", "expect": r"G:\workIns\conda\envs\pytorch",
             "note": "PATH 里 4 个 python（首个是 WorkBuddy 3.13.12），AI 解释器不在 PATH——AI 任务必须用完整路径"},
            {"cmd": "pip", "expect": r"G:\workIns\conda\envs\pytorch",
             "note": "PATH 的 pip 属于 base/3.14；给 AI 环境装包用 python -m pip"},
            {"cmd": "git", "expect": r"D:\wofkIns\Git\cmd",
             "note": "PATH 首个是 WorkBuddy 内置 PortableGit；手动 Git 在 D:\\wofkIns\\Git"},
            {"cmd": "conda", "expect": r"D:\wofkIns\anaconda3\Scripts",
             "note": "PATH 里的 Conda 是 D 盘 base（仅 base 环境；AI 环境在 G 盘）"},
            {"cmd": "mvn", "expect": r"D:\wofkIns\apache-maven-3.9.9",
             "note": "mvn 与 mvn.cmd 同时存在属正常"},
            {"cmd": "node", "expect": r"C:\Users\marco\.workbuddy\binaries\node",
             "note": "PATH 首个是 WorkBuddy 内置 node 22；D 盘另有一套"},
            {"cmd": "npm", "expect": r"C:\Users\marco\.workbuddy\binaries\node",
             "note": "npm 与 npm.cmd 同时存在属正常"},
            {"cmd": "java", "expect": r"D:\wofkIns\jdk-17.0.0.1", "note": "唯一 JDK 17"},
        ],

        # ── 环境变量：只读展示 + 与预期比对（值来自 os.environ）──────────
        "env_vars": [
            {"name": "HF_HOME", "expect": r"G:\study\AI\cache\huggingface", "note": "模型/数据集缓存位置"},
            {"name": "HF_ENDPOINT", "expect": "https://hf-mirror.com", "note": "HF 镜像源，加速下载"},
            {"name": "JAVA_HOME", "expect": r"D:\wofkIns\jdk-17.0.0.1", "note": "Java 开发工具路径"},
            {"name": "MAVEN_HOME", "expect": r"D:\wofkIns\apache-maven-3.9.9", "note": ""},
            {"name": "PATH", "expect": "", "note": "太长不全文展示；PATH 中命令解析见「PATH 真相」面板"},
        ],

        # ── 常用命令库（一键复制；仅文本，不自动执行）────────────────────
        # 来源：本机环境手册（事实源）+ 各工具官方文档常用命令。
        # 约定：note 里标注「需管理员」「未安装」「PATH 外」等，避免误用。
        "command_lib": [
            {"group": "① 服务启停（CMD / 需管理员）", "items": [
                {"cmd": "net start SunshineService", "note": "启动串流服务"},
                {"cmd": "net stop SunshineService", "note": "停止串流服务"},
                {"cmd": "net start Tailscale", "note": "启动 Tailscale 组网"},
                {"cmd": "net stop Tailscale", "note": "停止 Tailscale"},
                {"cmd": "net start MySQL", "note": "启动 MySQL 5.7（3306）"},
                {"cmd": "net start mysql80", "note": "启动 MySQL 8.0（3307，推荐）"},
                {"cmd": "net stop mysql80", "note": "停止 MySQL 8.0"},
                {"cmd": "services.msc", "note": "打开服务图形界面（无需管理员即可查看）"},
            ]},
            {"group": "② 服务启停（PowerShell 替代）", "items": [
                {"cmd": "Start-Service mysql80", "note": "启动服务（可换 MySQL/Tailscale）"},
                {"cmd": "Stop-Service mysql80", "note": "停止服务"},
                {"cmd": "Get-Service MySQL, mysql80", "note": "查看 MySQL 两服务状态"},
                {"cmd": "Restart-Service mysql80", "note": "重启服务"},
            ]},
            {"group": "③ MySQL（客户端不在 PATH，写全路径）", "items": [
                {"cmd": r'"D:\wofkIns\mysql\mysql-8.0.29-ini\bin\mysql.exe" -u root -p -P 3307', "note": "连 8.0（3307，推荐）"},
                {"cmd": r'"D:\wofkIns\mysql\mysql-5.7.19-ini\bin\mysql.exe" -u root -p -P 3306', "note": "连 5.7（3306）"},
                {"cmd": "SELECT VERSION();", "note": "登录后：看版本"},
                {"cmd": "SHOW DATABASES;", "note": "登录后：看数据库"},
                {"cmd": "CREATE DATABASE demo DEFAULT CHARACTER SET utf8mb4;", "note": "登录后：建库（用 utf8mb4 支持 emoji）"},
            ]},
            {"group": "④ Java / JDK（17.0.0.1，PATH 外）", "items": [
                {"cmd": r'"D:\wofkIns\jdk-17.0.0.1\bin\java.exe" -version', "note": "看版本（输出在 stderr）"},
                {"cmd": r'"D:\wofkIns\jdk-17.0.0.1\bin\javac.exe" -version', "note": "看编译器版本"},
                {"cmd": "echo %JAVA_HOME%", "note": "CMD 查看 JAVA_HOME（Git Bash 用 echo $JAVA_HOME）"},
                {"cmd": "javac -encoding UTF-8 Main.java", "note": "显式 UTF-8 编译，避免 GBK 乱码"},
            ]},
            {"group": "⑤ Maven（3.9.9，PATH 外）", "items": [
                {"cmd": r'"D:\wofkIns\apache-maven-3.9.9\bin\mvn.cmd" -version', "note": "看版本"},
                {"cmd": "mvn clean package", "note": "清理并打包"},
                {"cmd": "mvn -DskipTests package", "note": "跳过测试打包"},
                {"cmd": "mvn dependency:tree", "note": "查看依赖树"},
                {"cmd": "mvn help:evaluate -Dexpression=settings.localRepository -q -DforceStdout", "note": "看本地仓库实际路径"},
            ]},
            {"group": "⑥ Node.js / npm（v22.22.2，PATH 中）", "items": [
                {"cmd": "node -v && npm -v && npx -v", "note": "一次看三个版本"},
                {"cmd": "npm config get registry", "note": "看当前镜像源"},
                {"cmd": "npm config set registry https://registry.npmmirror.com/", "note": "切淘宝镜像（改回用 npmjs.org）"},
                {"cmd": "npm ls -g --depth=0", "note": "列出全局包"},
                {"cmd": "npm init -y && npm install", "note": "初始化并安装依赖"},
                {"cmd": "corepack enable", "note": "启用 yarn/pnpm 支持"},
            ]},
            {"group": "⑦ Python（多版本，注意 PATH 优先级）", "items": [
                {"cmd": "where python", "note": "看 PATH 里所有 python（首个生效）"},
                {"cmd": "python -c \"import sys;print(sys.executable)\"", "note": "看当前 python 到底是哪个"},
                {"cmd": "py -0p", "note": "列出所有 py launcher 注册的 Python"},
                {"cmd": "python -m pip -V", "note": "确认 pip 属于哪个解释器"},
                {"cmd": "python -m pip install <包名>", "note": "推荐：确保装到当前解释器"},
                {"cmd": "python -m venv .venv", "note": "建虚拟环境隔离"},
            ]},
            {"group": "⑧ Conda（两套：D 盘 PATH 中 / G 盘 AI 用）", "items": [
                {"cmd": "conda env list", "note": "列出 Conda 环境"},
                {"cmd": "conda info", "note": "看 Conda 配置信息"},
                {"cmd": r'"D:\wofkIns\anaconda3\Scripts\conda.exe" env list', "note": "指定 D 盘 Conda（PATH 中那套）"},
                {"cmd": r"conda activate G:\workIns\conda\envs\pytorch", "note": "激活 G 盘 AI 环境（已实测可行）"},
                {"cmd": "conda create -n myenv python=3.11 -y", "note": "新建环境"},
                {"cmd": "conda deactivate", "note": "退出当前环境"},
            ]},
            {"group": "⑨ AI / PyTorch / HuggingFace（G 盘 pytorch 环境）", "items": [
                {"cmd": "nvidia-smi", "note": "看 GPU / 显存占用"},
                {"cmd": r'G:\workIns\conda\envs\pytorch\python.exe -c "import torch;print(torch.__version__,torch.cuda.is_available())"', "note": "验证 torch 与 CUDA"},
                {"cmd": r'G:\workIns\conda\envs\pytorch\python.exe -c "import transformers;print(transformers.__version__)"', "note": "验证 transformers"},
                {"cmd": r'G:\workIns\conda\envs\pytorch\python.exe -m pip list', "note": "查 AI 环境已装包"},
                {"cmd": "echo %HF_HOME%", "note": "看 HF 缓存目录（应为 G:\\study\\AI\\cache\\huggingface）"},
                {"cmd": "echo %HF_ENDPOINT%", "note": "看 HF 镜像源（应为 hf-mirror.com）"},
            ]},
            {"group": "⑩ Git（官方 cheat sheet 常用）", "items": [
                {"cmd": r'"D:\wofkIns\Git\cmd\git.exe" status', "note": "指定手动 Git（非 WorkBuddy 内置）"},
                {"cmd": "git add . && git commit -m \"msg\"", "note": "暂存并提交"},
                {"cmd": "git log --oneline -10", "note": "最近 10 条提交"},
                {"cmd": "git switch -c feature-x", "note": "新建并切换分支"},
                {"cmd": "git fetch && git pull", "note": "拉取远程更新"},
                {"cmd": "git push origin main", "note": "推送到远程"},
                {"cmd": "git stash", "note": "暂存当前改动"},
                {"cmd": "git config --global user.name", "note": "查看全局用户名"},
            ]},
            {"group": "⑪ IDE（VSCode / IDEA）", "items": [
                {"cmd": "code .", "note": "用 VSCode 打开当前目录"},
                {"cmd": "code --list-extensions", "note": "列出已装扩展"},
                {"cmd": "code --install-extension <ext>", "note": "安装扩展"},
                {"cmd": "idea64.exe", "note": "启动 IntelliJ IDEA Ultimate"},
            ]},
            {"group": "⑫ Tailscale 组网（PATH 外，写全路径）", "items": [
                {"cmd": r'"F:\Game\tailscale\tailscale.exe" status', "note": "查看组网节点"},
                {"cmd": r'"F:\Game\tailscale\tailscale.exe" ip', "note": "看本机组网 IP（100.75.245.81）"},
                {"cmd": r'"F:\Game\tailscale\tailscale.exe" up', "note": "上线"},
                {"cmd": r'"F:\Game\tailscale\tailscale.exe" down', "note": "下线"},
            ]},
            {"group": "⑬ .NET（仅运行时，无 SDK）", "items": [
                {"cmd": "dotnet --info", "note": "看 SDK / 运行时总览"},
                {"cmd": "dotnet --list-runtimes", "note": "列出运行时（当前 7.0.20 / 9.0.22）"},
                {"cmd": "dotnet --list-sdks", "note": "列出 SDK（当前为空，需装 SDK 才能开发）"},
            ]},
            {"group": "⑭ 端口 / 网络排查", "items": [
                {"cmd": "netstat -ano | findstr LISTENING", "note": "CMD：所有监听端口与 PID"},
                {"cmd": "netstat -ano | findstr :8080", "note": "CMD：查某端口被谁占用"},
                {"cmd": "Get-NetTCPConnection -LocalPort 3306", "note": "PowerShell：查端口占用"},
                {"cmd": "ipconfig /all", "note": "看全部网络配置"},
                {"cmd": "ping 100.75.245.81", "note": "测试本机 Tailscale IP 连通"},
            ]},
            {"group": "⑮ 系统 / 进程排查", "items": [
                {"cmd": "tasklist", "note": "列出所有进程"},
                {"cmd": "tasklist | findstr python", "note": "找残留的 python 进程"},
                {"cmd": "wmic process where \"name='python.exe'\" get ProcessId,CommandLine", "note": "看 python 进程命令行（找重复 Web）"},
                {"cmd": "systeminfo", "note": "看系统完整信息"},
            ]},
            {"group": "⑯ 未安装软件（备查，运行会报错）", "items": [
                {"cmd": "docker --version", "note": "Docker 未安装"},
                {"cmd": "gradle -version", "note": "Gradle 未装（建议用项目 gradlew）"},
                {"cmd": "ollama --version", "note": "Ollama 未安装（默认端口 11434）"},
                {"cmd": "dotnet new console", "note": ".NET 无 SDK，当前会失败"},
            ]},
        ],

        # ── 关键进程检测：扫描这些关键字的进程（避免重复启动 Web）────────
        "watch_processes": ["web.py", "webctl.py", "serve_api.py"],
    },
}
