# -*- coding: utf-8 -*-
"""
web.py —— 通用 Web 控制台后端（配置驱动，仅监听 127.0.0.1）
复用 core 的探测缓存；所有数据接口返回 JSON，供 index.html 消费。
"""
import json
import re
import subprocess
import threading
import webbrowser
from pathlib import Path

from flask import Flask, jsonify, send_from_directory, request

from core import (
    P, SHORT, ROOT, PROJ, EXP, DATA, NOTES, WEB, HF_HOME, PY_EXE,
    SERVE_PORT, WEB_PORT, PID_FILE, LOG_FILE, console,
    get_versions, port_open, pid_alive, read_pid, write_pid, clear_pid,
    kill_pid, csv_count, free_gb, _resolve,
    pick_web_port, write_web_port, read_web_port,
)

# Web 实际监听端口：由 pick_web_port 决策后写入，供接口回传
ACTIVE_PORT = read_web_port()

app = Flask(__name__, static_folder=None)
ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


@app.after_request
def _no_cache(resp):
    """彻底禁用缓存：改了前端后浏览器必须拿到最新 HTML，避免旧 JS 残留报错。"""
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    resp.headers.pop("ETag", None)
    resp.headers.pop("Last-Modified", None)
    return resp


def _clean(s):
    return ANSI_RE.sub("", s)


def run_cli(args, timeout=180):
    """调用 CLI 并回传去色文本（Web 与 CLI 共用同一逻辑，不重复实现）。"""
    code = (
        f"import sys; sys.path.insert(0, r'{Path(__file__).parent}'); "
        f"import cli; sys.argv=['{SHORT}'] + {args!r}; cli.app(standalone_mode=False)"
    )
    try:
        out = subprocess.run([str(PY_EXE), "-c", code], cwd=str(ROOT),
                             capture_output=True, text=True, timeout=timeout)
        return _clean((out.stdout or "") + (out.stderr or ""))
    except Exception as e:
        return f"执行失败：{e}"


# ── 页面与静态资源 ───────────────────────────────────────────────
# index.html 的唯一事实源是 engine/ 目录（本文件所在处）。
# 以前 web/ 另存一份副本，改了 engine 忘同步就会出现"菜单是旧的/面板空白"。
INDEX_DIR = Path(__file__).parent


@app.route("/")
def index():
    return send_from_directory(str(INDEX_DIR), "index.html")


@app.route("/<path:filename>")
def static_files(filename):
    # 直接访问 /index.html 也走事实源；其余静态资源（marked.min.js 等）仍在 web/
    if filename == "index.html":
        return send_from_directory(str(INDEX_DIR), filename)
    return send_from_directory(str(WEB), filename)


# ── 元数据（前端据此渲染主题名/命令表）──────────────────────────
@app.route("/api/meta")
def api_meta():
    return jsonify({
        "name": P["name"], "short": SHORT, "desc": P["desc"],
        "serve_predict": P["serve"].get("predict", "") if P["serve"]["enabled"] else "",
        "sections": P.get("ui", {}).get("sections"),   # 主题可定制面板列表；None=用默认
        "commands": [
            {"cmd": "status", "desc": "环境/版本/服务状态"},
            {"cmd": "doctor", "desc": "环境一键体检"},
            {"cmd": "quiz", "desc": "记忆抽测"},
            {"cmd": "data", "desc": "数据/标签/样例"},
            {"cmd": "inspect", "desc": "产物含义+指标"},
            {"cmd": "curve", "desc": "训练曲线"},
            {"cmd": "serve", "desc": "启动推理服务"},
            {"cmd": "stop", "desc": "停止推理服务"},
            {"cmd": "cache", "desc": "缓存管理"},
        ],
    })


@app.route("/api/health")
def api_health():
    return jsonify({"ok": True, "topic": P["name"]})


@app.route("/api/status")
def api_status():
    v = get_versions()
    return jsonify({
        "interpreter": str(PY_EXE),
        "interpreter_exists": PY_EXE.exists(),
        "versions": v["versions"],
        "cuda": v.get("cuda"),
        "gpu": v.get("gpu"),
        "cache": str(HF_HOME) if HF_HOME else "未配置",
        "serve": {"port": SERVE_PORT, "running": port_open(SERVE_PORT)} if SERVE_PORT else None,
        "web_port": ACTIVE_PORT, "configured_port": WEB_PORT,
    })


def _with_exists(items):
    """给一组 {name,path,...} 补上 exists 字段。"""
    out = []
    for it in items:
        d = dict(it)
        d["exists"] = _resolve(it["path"]).exists() if it.get("path") else None
        out.append(d)
    return out


@app.route("/api/facts")
def api_facts():
    """主题自带的静态事实（关键路径 / 配置文件 / 产物路径 / 端口 / 磁盘）。"""
    facts = P.get("facts", {})
    return jsonify({
        "paths": _with_exists(facts.get("paths", [])),
        "config_files": _with_exists(facts.get("config_files", [])),
        "products": _with_exists(facts.get("products", [])),
        "ports": facts.get("ports", []),
        "disks": facts.get("disks", []),
        "command_lib": facts.get("command_lib", []),
    })


@app.route("/api/services")
def api_services():
    """实测 Windows 服务运行状态（只读），并回传启动命令供复制。"""
    import subprocess as _sp
    out = []
    for it in P.get("facts", {}).get("services", []):
        svc = it["svc"]
        state, ok = "未知", False
        try:
            r = _sp.run(["powershell", "-NoProfile", "-Command",
                         f"(Get-Service -Name '{svc}' -ErrorAction SilentlyContinue).Status"],
                        capture_output=True, text=True, timeout=15)
            state = (r.stdout or "").strip().splitlines()[0] if (r.stdout or "").strip() else "未找到"
            ok = state.lower() == str(it.get("expect", "")).lower()
        except Exception as e:
            state = f"查询失败：{e}"
        out.append({"name": it["name"], "svc": svc, "state": state,
                    "expect": it.get("expect", ""), "ok": ok,
                    "start": it.get("start", ""),
                    "stop": f"net stop {svc}  (管理员)", "note": it.get("note", "")})
    return jsonify({"services": out})


@app.route("/api/software")
def api_software():
    """软件状态：实时版本（合并 get_versions）+ 路径存在性 + 启动命令。"""
    versions = get_versions().get("versions", {})
    items = []
    for s in P.get("facts", {}).get("software", []):
        label = s.get("probe_label", "")
        ver = versions.get(label, "") if label else ""
        path = _resolve(s["path"]) if s.get("path") else None
        items.append({
            "name": s["name"], "category": s["category"],
            "version": ver if ver and ver != "-" else "",
            "available": bool(ver and ver != "-") if label else (path.exists() if path else False),
            "path": str(path) if path else "", "path_exists": path.exists() if path else None,
            "start": s.get("start", ""), "note": s.get("note", ""),
        })
    return jsonify({"software": items})


@app.route("/api/test")
def api_test():
    """快速自检：全部只读，不改系统。返回每项 PASS/WARN/FAIL。"""
    results = []

    def add(name, ok, detail, level_ok="PASS"):
        results.append({"name": name, "status": level_ok if ok else "FAIL", "detail": str(detail)})

    # 1) 解释器
    add("AI 解释器", PY_EXE.exists(), str(PY_EXE))
    # 2) 关键路径
    paths = _with_exists(P.get("facts", {}).get("paths", []))
    miss = [p["name"] for p in paths if not p["exists"]]
    add("关键路径", not miss, "全部存在" if not miss else "缺失：" + "、".join(miss))
    # 3) 版本探测
    versions = get_versions().get("versions", {})
    bad = [k for k, v in versions.items() if not v or v == "-"]
    add("版本探测", not bad,
        f"{len(versions) - len(bad)}/{len(versions)} 项可用" if not bad else "失败：" + "、".join(bad))
    # 4) GPU
    cuda = get_versions().get("cuda")
    gpu = get_versions().get("gpu")
    add("CUDA/GPU", bool(cuda), f"{gpu}（CUDA {'可用' if cuda else '不可用'}）", level_ok="PASS")
    # 5) Web 自身端口连通
    add("Web 服务", port_open(ACTIVE_PORT), f"127.0.0.1:{ACTIVE_PORT}")
    # 6) 服务端口连通（只读探测，报告状态不判定失败）
    port_rows = []
    facts = P.get("facts", {})
    # 从 services 里取 svc 名对应的端口不易，直接用 ports 快照做连通探测说明
    for it in facts.get("ports", []):
        raw = str(it.get("port", ""))
        first = raw.split("/")[0].strip()
        if first.isdigit():
            port_rows.append(f"{first}({it.get('use','')}):{'通' if port_open(int(first)) else '不通'}")
    results.append({"name": "常用端口连通", "status": "INFO",
                    "detail": "；".join(port_rows) if port_rows else "无可探测端口"})
    # 7) 配置文件 / 产物路径（报告存在性，缺失为 WARN 不判失败）
    for group_name, key in [("配置文件", "config_files"), ("产物路径", "products")]:
        items = _with_exists(facts.get(key, []))
        have = sum(1 for x in items if x["exists"])
        results.append({"name": group_name, "status": "PASS" if have == len(items) else "WARN",
                        "detail": f"{have}/{len(items)} 存在"})
    passed = sum(1 for r in results if r["status"] == "PASS")
    failed = sum(1 for r in results if r["status"] == "FAIL")
    return jsonify({"results": results, "passed": passed, "failed": failed})


@app.route("/api/service/action", methods=["POST"])
def api_service_action():
    """Windows 服务启停：仅允许 config 白名单服务名，尝试执行并回传结果。
    非管理员会失败——回传明确提示，前端展示命令供手动执行。"""
    data = request.get_json(silent=True) or {}
    svc = str(data.get("svc", ""))
    action = str(data.get("action", ""))
    allowed = {it["svc"] for it in P.get("facts", {}).get("services", [])}
    if svc not in allowed:
        return jsonify({"ok": False, "msg": "服务名不在白名单，拒绝执行"})
    if action not in ("start", "stop"):
        return jsonify({"ok": False, "msg": "仅支持 start/stop"})
    try:
        cmd = f"net {action} {svc}"
        r = subprocess.run(["cmd", "/c", cmd], capture_output=True, text=True, timeout=40)
        text = ((r.stdout or "") + (r.stderr or "")).strip()
        # net 成功时输出 "服务...正在启动/停止" 且 returncode 0
        ok = r.returncode == 0
        msg = text if text else ("操作已提交" if ok else "操作失败")
        if not ok and ("权限" in text or "denied" in text.lower() or "5" == str(r.returncode)):
            msg = "需要管理员权限。请以管理员身份运行终端后执行：" + cmd + "\n" + text
        return jsonify({"ok": ok, "msg": msg, "cmd": cmd})
    except Exception as e:
        return jsonify({"ok": False, "msg": f"执行失败：{e}；请手动运行 net {action} {svc}"})


@app.route("/api/path-truth")
def api_path_truth():
    """PATH 真相：where 实测每个命令的解析结果，多候选/期望未命中给预警。"""
    out = []
    for c in P.get("facts", {}).get("path_commands", []):
        cmd = c["cmd"]
        paths, multi, hit_expect = [], False, True
        try:
            if __import__("sys").platform == "win32":
                r = subprocess.run(["cmd", "/c", f"where {cmd}"], capture_output=True, text=True, timeout=20)
                paths = [x.strip() for x in (r.stdout or "").splitlines() if x.strip()]
            else:
                r = subprocess.run(["which", "-a", cmd], capture_output=True, text=True, timeout=20)
                paths = [x.strip() for x in (r.stdout or "").splitlines() if x.strip()]
        except Exception as e:
            paths = []
        multi = len(paths) > 1
        expect = c.get("expect", "")
        if expect:
            hit_expect = any(expect.lower().replace("/", "\\") in p.lower().replace("/", "\\") for p in paths)
        out.append({"cmd": cmd, "paths": paths, "effective": paths[0] if paths else "",
                    "count": len(paths), "multi": multi, "expect": expect,
                    "hit_expect": hit_expect, "note": c.get("note", "")})
    return jsonify({"commands": out})


@app.route("/api/env-vars")
def api_env_vars():
    """环境变量：只读展示当前值 + 与预期比对。PATH 不全文回传。"""
    import os as _os
    out = []
    for v in P.get("facts", {}).get("env_vars", []):
        name = v["name"]
        val = _os.environ.get(name, "")
        expect = v.get("expect", "")
        matched = (not expect) or (val.lower().replace("/", "\\") == expect.lower().replace("/", "\\"))
        shown = val
        if name == "PATH" and len(val) > 260:
            shown = val[:260] + f" …（共 {len(val)} 字符）"
        out.append({"name": name, "value": shown, "set": bool(val),
                    "expect": expect, "matched": matched, "note": v.get("note", "")})
    return jsonify({"vars": out})


@app.route("/api/ports-live")
def api_ports_live():
    """实时监听端口：psutil 扫描 LISTENING，关联进程；标注已知用途与冲突。"""
    # 已知端口用途（来自 facts.ports 的快照）
    known = {}
    for it in P.get("facts", {}).get("ports", []):
        for token in str(it.get("port", "")).split("/"):
            token = token.strip()
            if token.isdigit():
                known[int(token)] = it.get("use", "")
    rows = []
    try:
        import psutil
        for c in psutil.net_connections(kind="inet"):
            if c.status != psutil.CONN_LISTEN or not c.laddr or not c.pid:
                continue
            port = getattr(c.laddr, "port", None)
            ip = getattr(c.laddr, "ip", "")
            if not port:
                continue
            pname = ""
            try:
                pname = psutil.Process(c.pid).name()
            except Exception:
                pass
            rows.append({"port": port, "ip": ip, "pid": c.pid, "proc": pname,
                         "use": known.get(port, ""), "known": port in known})
    except Exception as e:
        return jsonify({"error": f"端口扫描失败：{e}", "rows": []})
    # 冲突检测：同一端口多个不同 PID 监听
    from collections import defaultdict as _dd
    by_port = _dd(list)
    for r in rows:
        by_port[r["port"]].append(r)
    conflicts = [p for p, rs in by_port.items() if len({x["pid"] for x in rs}) > 1]
    for r in rows:
        r["conflict"] = r["port"] in conflicts
    rows.sort(key=lambda x: (not x["known"], x["port"]))
    return jsonify({"rows": rows, "conflicts": conflicts,
                    "total": len(rows), "known_count": sum(1 for r in rows if r["known"])})


@app.route("/api/processes")
def api_processes():
    """关键进程检测：扫描命令行含 watch 关键字的进程（避免重复启动 Web）。"""
    keys = P.get("facts", {}).get("watch_processes", [])
    found = []
    try:
        import psutil
        for p in psutil.process_iter(["pid", "name", "cmdline", "create_time"]):
            try:
                info = p.info
                cmd = " ".join(info.get("cmdline") or [])
                if any(k in cmd for k in keys):
                    import datetime as _dt
                    ct = info.get("create_time")
                    found.append({"pid": info["pid"], "name": info.get("name", ""),
                                  "cmd": cmd,
                                  "start": _dt.datetime.fromtimestamp(ct).strftime("%m-%d %H:%M:%S") if ct else "",
                                  "is_self": info["pid"] == __import__("os").getpid()})
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    except Exception as e:
        return jsonify({"error": str(e), "processes": []})
    return jsonify({"processes": found, "keys": keys})


@app.route("/api/open-path", methods=["POST"])
def api_open_path():
    """在资源管理器中打开路径：仅允许 facts 里登记过的目录，白名单防越权。"""
    data = request.get_json(silent=True) or {}
    target = str(data.get("path", "")).strip()
    allowed = set()
    facts = P.get("facts", {})
    for key in ("paths", "config_files", "products"):
        for it in facts.get(key, []):
            if it.get("path"):
                allowed.add(str(_resolve(it["path"])))
    # 也允许打开这些路径的父目录（如打开解释器所在文件夹）
    q = _resolve(target) if target else None
    if not q or str(q) not in allowed:
        return jsonify({"ok": False, "msg": "路径不在白名单，拒绝打开"})
    if not q.exists():
        return jsonify({"ok": False, "msg": "路径不存在"})
    try:
        folder = str(q) if q.is_dir() else str(q.parent)
        if __import__("sys").platform == "win32":
            subprocess.Popen(["explorer", folder])
        else:
            subprocess.Popen(["xdg-open", folder])
        return jsonify({"ok": True, "msg": f"已打开：{folder}"})
    except Exception as e:
        return jsonify({"ok": False, "msg": f"打开失败：{e}"})


@app.route("/api/doctor")
def api_doctor():
    return jsonify({"text": run_cli(["doctor"])})


@app.route("/api/data")
def api_data():
    files = []
    for spec in P["data"]["files"]:
        p = DATA / spec["name"]
        files.append({"name": spec["name"], "exists": p.exists(),
                      "count": csv_count(p) if p.exists() else None,
                      "expect": spec.get("expect"), "columns": spec.get("columns", "")})
    labels = None
    src = EXP / P["data"]["label_source"] if P["data"].get("label_source") else None
    if src and src.exists():
        try:
            labels = json.loads(src.read_text(encoding="utf-8")).get("id2label")
        except Exception:
            pass
    return jsonify({"files": files, "label_note": P["data"].get("label_note"),
                    "labels": labels})


@app.route("/api/inspect")
def api_inspect():
    out = []
    if EXP.exists():
        meanings = P["artifacts"]["meanings"]
        for p in sorted(EXP.iterdir()):
            out.append({"name": p.name,
                        "size_mb": round(p.stat().st_size / 1024 ** 2, 1) if p.is_file() else None,
                        "meaning": meanings.get(p.name, "检查点 / 其它产物" if p.is_dir() else "辅助文件")})
    metrics = {}
    for fn in P["artifacts"].get("metrics_files", []):
        p = EXP / fn
        if p.exists():
            try:
                metrics[fn] = json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                pass
    return jsonify({"files": out, "metrics": metrics})


@app.route("/api/curve")
def api_curve():
    hf = EXP / P["artifacts"]["history_file"]
    if not hf.exists():
        return jsonify({"error": "未找到训练历史", "path": str(hf)})
    d = json.loads(hf.read_text(encoding="utf-8"))
    hist = d.get(P["artifacts"]["history_key"], [])
    xkey = P["artifacts"]["x_key"]
    series = {m: [] for m in P["artifacts"]["curve_metrics"]}
    for h in hist:
        for m in series:
            if m in h and isinstance(h[m], (int, float)):
                series[m].append({"x": h.get(xkey), "y": h[m]})
    return jsonify({"series": series})


@app.route("/api/quiz/questions")
def api_quiz_questions():
    mod_name = P["question_module"].replace(".py", "")
    try:
        bank = __import__(mod_name).QUESTION_BANK
    except Exception as e:
        return jsonify({"error": str(e)})
    for q in bank:
        q["a"] = q.get("a", "").replace("<short>", SHORT)
        q["q"] = q.get("q", "").replace("<short>", SHORT)
    topics = {}
    for q in bank:
        topics[q["t"]] = topics.get(q["t"], 0) + 1
    return jsonify({"total": len(bank), "topics": topics, "questions": bank})


@app.route("/api/cache")
def api_cache():
    items = []
    for it in P["cache"]["items"]:
        p = _resolve(it["path"])
        size = None
        if p.exists():
            size = sum(f.stat().st_size for f in p.rglob("*") if f.is_file()) if p.is_dir() else p.stat().st_size
        items.append({"name": it["name"], "path": str(p), "safe": it.get("safe", False),
                      "size_mb": round(size / 1024 ** 2, 1) if size is not None else None,
                      "note": it.get("note", "")})
    return jsonify({"items": items})


@app.route("/api/cache/clean", methods=["POST"])
def api_cache_clean():
    import shutil as _sh
    cleaned = []
    for it in P["cache"]["items"]:
        if not it.get("safe"):
            continue
        p = _resolve(it["path"])
        try:
            if p.is_dir():
                _sh.rmtree(p)
            elif p.exists():
                p.unlink()
            cleaned.append(it["name"])
        except Exception:
            pass
    return jsonify({"cleaned": cleaned})


@app.route("/api/serve", methods=["POST"])
def api_serve():
    if not P["serve"]["enabled"]:
        return jsonify({"ok": False, "msg": "本主题未启用服务"})
    if not PY_EXE.exists():
        return jsonify({"ok": False, "msg": f"解释器不存在：{PY_EXE}"})
    d = request.get_json(silent=True) or {}
    port = int(d.get("port") or SERVE_PORT)
    if port_open(port):
        return jsonify({"ok": False, "msg": f"端口 {port} 已占用"})
    script = _resolve(P["serve"]["script"]) if P["serve"].get("script") else None
    if not script or not script.exists():
        return jsonify({"ok": False, "msg": f"服务脚本不存在：{script}"})
    import os
    env = dict(os.environ)
    env["HFKIT_SERVE_PORT"] = str(port)
    log = LOG_FILE.open("a", encoding="utf-8")
    flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS if __import__("sys").platform == "win32" else 0
    proc = subprocess.Popen([str(PY_EXE), str(script)], cwd=str(ROOT), env=env,
                            stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
    write_pid(proc.pid)
    for _ in range(30):
        if port_open(port):
            return jsonify({"ok": True, "pid": proc.pid, "port": port})
        if not pid_alive(proc.pid):
            return jsonify({"ok": False, "msg": "进程提前退出，请查看日志"})
        import time as _t
        _t.sleep(1)
    return jsonify({"ok": True, "pid": proc.pid, "port": port, "msg": "已启动，仍在加载"})


@app.route("/api/stop", methods=["POST"])
def api_stop():
    pid = read_pid()
    stopped = False
    if pid and pid_alive(pid):
        stopped = kill_pid(pid)
    clear_pid()
    return jsonify({"ok": stopped or pid is None, "stopped_pid": pid})


@app.route("/api/docs")
def api_docs():
    docs = []
    if NOTES.exists():
        for p in sorted(NOTES.glob("*.md")):
            docs.append({"name": p.stem, "content": p.read_text(encoding="utf-8", errors="replace")})
    return jsonify({"docs": docs})


def _preflight():
    """启动前预检：智能选端口（原服务自动关闭 / 其它程序顺延），失败给中文提示。"""
    if not PY_EXE.exists():
        print(f"\n  [解释器缺失] {PY_EXE}", flush=True)
        print("  请修改 config.py 的 env.python_exe。\n", flush=True)
        return None
    import os as _os
    preset = _os.environ.get("HFKIT_WEB_PORT")
    if preset and preset.isdigit():
        # CLI 已完成端口决策，直接采用，避免二次决策把顺延端口再次 +1
        return int(preset)
    port, action, killed = pick_web_port(WEB_PORT)
    if not port:
        print(f"\n  [端口耗尽] {WEB_PORT} 起的 20 个端口都被占用，无法启动。", flush=True)
        print("  请手动结束占用进程，或在 config.py 调整 web_port。\n", flush=True)
        return None
    if action == "reused":
        print(f"  → 已关闭上次的 Web（PID {killed}），复用端口 {port}", flush=True)
    elif action == "shifted":
        print(f"  → 端口顺延，改用 {port}（配置端口 {WEB_PORT} 被其它程序占用）", flush=True)
    return port


if __name__ == "__main__":
    active = _preflight()
    if not active:
        raise SystemExit(1)
    ACTIVE_PORT = active
    write_web_port(active)
    print(f"[{SHORT}-web] {P['name']} http://127.0.0.1:{ACTIVE_PORT}", flush=True)
    threading.Timer(1.5, lambda: webbrowser.open(f"http://127.0.0.1:{ACTIVE_PORT}")).start()
    app.run(host="127.0.0.1", port=ACTIVE_PORT, threaded=True, debug=False, use_reloader=False)
